#! /usr/bin/python
from generaXmlViajes import *

generaXmlViajes()
