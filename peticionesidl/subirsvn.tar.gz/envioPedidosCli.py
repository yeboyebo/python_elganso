#! /usr/bin/python
from generaXmlPedidosCli import *

generaXmlPedidosCli()
