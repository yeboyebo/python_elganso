#! /usr/bin/python
from generaXmlPedidos import *

generaXmlPedidos()