#! /usr/bin/python
from generaXmlViajesCli import *

generaXmlViajesCli()
