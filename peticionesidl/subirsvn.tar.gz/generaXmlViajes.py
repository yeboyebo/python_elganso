import xml.etree.cElementTree as ET
from xml.etree.ElementTree import tostring
from util import *


def generaXmlViajes():
    xmlstring = ""
    res = {}
    res[0] = False
    res[1] = ""

    cx = creaConexion()

    try:
        recOrd = ET.Element("reception_orders")
        int15 = ET.SubElement(recOrd, "int15")

        cx["cur"].execute("SELECT v.codmultitransstock AS codigo, v.idviajemultitrans as idviaje, v.tiempotransito as fechaentrada, v.fecha as fecha, a.codalmacenidl as codalmacen, a.nombre as nombrealmacen, t.codproveedor as codproveedor FROM tpv_viajesmultitransstock v INNER JOIN almacenesidl a on v.codalmadestino = a.codalmacen INNER JOIN almacenes al on a.codalmacen = al.codalmacen INNER JOIN tpv_tiendas t on v.codalmaorigen = t.codalmacen WHERE al.egcodtransportista = 'id' AND (v.estado = 'EN TRANSITO' OR v.estado = 'ENVIADO PARCIAL') AND v.enviocompletado = true AND v.azkarok = false AND v.fecha >= '2017-06-01' AND t.codproveedor is not null and v.idviajemultitrans in (select idviajemultitrans from tpv_lineasmultitransstock where idviajemultitrans = v.idviajemultitrans) order by v.fecha ASC LIMIT 1")

        rows = cx["cur"].fetchall()
        idViaje = Falseu
        if len(rows) > 0:
            for p in rows:
                idViaje = p["idviaje"]
                if not creaXmlRecepcionViaje(p, int15, cx):
                    print("No hay Viajes con líneas que enviar")
                    return False

            tree = ET.ElementTree(recOrd)
            tree.write("./recepciones/xmlViajes.xml")

            xmlstring = tostring(recOrd, 'utf-8', method="xml").decode("ISO8859-15")
            # datosCX = dameDatosConexion("WSIDL_ENVREC_TEST", cx)
            datosCX = dameDatosConexion("WSIDL_ENVREC", cx)
            header = datosCX["header"]
            result = post_request(url, header, xmlstring)

            status = False
            if not result:
                res[0] = False
                res[1] = result
                print(result)
                print("Error enviando Viaje")
            else:
                res[0] = True
                res[1] = result

                root = ET.fromstring(result)
                child = root.find('int15/rub110')
                if child:
                    status = child.find("status").text

                tree = ET.ElementTree(root)
                tree.write("./recepciones/resViajes.xml")

            idlog = registraLog("ENV_RECEPCIONES", xmlstring, res, cx)
            if status:
                if status == "OK":
                    print("ok")
                    cx["cur"].execute("UPDATE tpv_viajesmultitransstock SET azkarok = true where idviajemultitrans = '" + str(idViaje) + "'")
                    cx["conn"].commit()
                else:
                    error = child.find("error_descriptions/error_description").text
                    print(error)
        else:
            print("No hay Viajes que enviar")

    except Exception as e:
        res[0] = False
        res[1] = e
        print(e)

    cierraConexion(cx)

    return True


def creaXmlRecepcionViaje(p, int15, cx):
    cx["cur"].execute("SELECT barcode, cantidad, idlinea, descripcion FROM tpv_lineasmultitransstock WHERE cantidad > 0 and idviajemultitrans = '" + str(p["idviaje"] + "'"))
    rows = cx["cur"].fetchall()
    numL = 1
    if len(rows) <= 0:
        return False

    rub110 = ET.SubElement(int15, "rub110")
    ET.SubElement(rub110, "activity_code").text = "GNS"
    ET.SubElement(rub110, "physical_depot_code").text = "GNS"
    ET.SubElement(rub110, "originator_code").text = "EL_GANSO"
    ET.SubElement(rub110, "receipt_reference").text = "V" + p["idviaje"] + "01"
    ET.SubElement(rub110, "receipt_type").text = "010"
    ET.SubElement(rub110, "receipt_reason_code").text = "DEV"
    ET.SubElement(rub110, "work_mode_code").text = "REC"
    ET.SubElement(rub110, "original_code").text = p["codproveedor"]
    ET.SubElement(rub110, "carrier_arrival_date_century").text = str(p["fechaentrada"])[0:2]
    ET.SubElement(rub110, "carrier_arrival_date_year").text = str(p["fechaentrada"])[2:4]
    ET.SubElement(rub110, "carrier_arrival_date_month").text = str(p["fechaentrada"])[5:7]
    ET.SubElement(rub110, "carrier_arrival_date_day").text = str(p["fechaentrada"])[8:10]
    ET.SubElement(rub110, "carrier_arrival_time").text = "0"

    rub119 = ET.SubElement(rub110, "rub119")
    ET.SubElement(rub119, "activity_code").text = "GNS"
    ET.SubElement(rub119, "physical_depot_code").text = "GNS"
    ET.SubElement(rub119, "originator_code").text = "EL_GANSO"
    ET.SubElement(rub119, "receipt_reference").text = "V" + p["idviaje"] + "01"
    ET.SubElement(rub119, "comment_line_no").text = "001"
    ET.SubElement(rub119, "comment_group").text = "OWN"

    if p["nombrealmacen"]:
        ET.SubElement(rub119, "comment").text = p["nombrealmacen"][0:70]
    else:
        ET.SubElement(rub119, "comment").text = ""

    for l in rows:
        rub120 = ET.SubElement(rub110, "rub120")
        ET.SubElement(rub120, "activity_code").text = "GNS"
        ET.SubElement(rub120, "physical_depot_code").text = "GNS"
        ET.SubElement(rub120, "originator_code").text = "EL_GANSO"
        ET.SubElement(rub120, "receipt_reference").text = "V" + p["idviaje"] + "01"
        ET.SubElement(rub120, "receipt_reference_line_no").text = str(numL)
        ET.SubElement(rub120, "item_code").text = str(l["barcode"])[0:16]
        ET.SubElement(rub120, "item_lv_code").text = "11"
        ET.SubElement(rub120, "level_1_quantity").text = str(int(l["cantidad"]))
        ET.SubElement(rub120, "owner_code").text = p["codalmacen"]
        numL += 1

    return True
