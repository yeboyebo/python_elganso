import xml.etree.cElementTree as ET
from xml.etree.ElementTree import tostring
from util import *


def generaXmlPedidos():
    xmlstring = ""
    res = {}
    res[0] = False
    res[1] = ""

    cx = creaConexion()

    try:
        recOrd = ET.Element("reception_orders")
        int15 = ET.SubElement(recOrd, "int15")

        cx["cur"].execute("SELECT p.codigo AS codigo, p.idpedido as idpedido, p.fechaentrada as fechaentrada, p.fecha as fecha, p.enviomodificado as enviomodificado, a.codalmacenidl as codalmacen, a.nombre as nombrealmacen, p.codproveedor as codproveedor, max(r.numenvio) as numenvio FROM pedidosprov p INNER JOIN almacenesidl a on p.codalmacen = a.codalmacen left outer join eg_pedidosrecibidos r on p.idpedido = r.idpedido WHERE p.enviado = true AND p.fichero is null AND p.codproveedor is not null and p.idpedido in (select idpedido from lineaspedidosprov where idpedido = p.idpedido) group by r.idpedido, p.codigo, p.idpedido, p.fechaentrada, p.fecha, p.enviomodificado, a.codalmacenidl, a.nombre, p.codproveedor order by p.fecha ASC limit 1")
        # and p.codigo in ('20130A000769','20170A001096')

        rows = cx["cur"].fetchall()
        idPedido = False
        if len(rows) > 0:
            for p in rows:
                idPedido = p["idpedido"]
                if not creaXmlRecepcionPedido(p, int15, cx):
                    print("No hay pedidos con líneas que enviar")
                    return False

            tree = ET.ElementTree(recOrd)
            tree.write("./recepciones/xmlPedidos_" + p["codigo"] + ".xml")

            xmlstring = tostring(recOrd, 'utf-8', method="xml").decode("ISO8859-15")
            # datosCX = dameDatosConexion("WSIDL_ENVREC_TEST", cx)
            datosCX = dameDatosConexion("WSIDL_ENVREC", cx)
            header = datosCX["header"]
            url = datosCX["url"]
            result = post_request(url, header, xmlstring)

            status = False
            print(result)

            if not result:
                res[0] = False
                res[1] = result
                print(result)
                print("Error enviando pedido")
                return False
            else:
                res[0] = True
                res[1] = result

                root = ET.fromstring(result)
                child = root.find('int15/rub110')
                if child:
                    status = child.find("status").text

                tree = ET.ElementTree(root)
                tree.write("./recepciones/resPedidos_" + p["codigo"] + ".xml")

            idlog = registraLog("ENV_RECEPCIONES", xmlstring, res, cx)
            if status:
                if status == "OK":
                    cx["cur"].execute("UPDATE pedidosprov SET fichero = '" + str(idlog) + "' where idpedido = " + str(idPedido))
                else:
                    error = child.find("error_descriptions/error_description").text
                    print(error)
                    cx["cur"].execute("UPDATE pedidosprov SET fichero = 'ERROR: " + str(idlog) + "' where idpedido = " + str(idPedido))
                cx["conn"].commit()
        else:
            print("No hay pedidos que enviar")
            return True

    except Exception as e:
        res[0] = False
        res[1] = e
        print(e)
        return False

    cierraConexion(cx)
    generaXmlPedidos()

    return True


def creaXmlRecepcionPedido(p, int15, cx):
    cx["cur"].execute("SELECT barcode, cantidad-totalenalbaran as cantidad, idlinea, descripcion FROM lineaspedidosprov WHERE cantidad-totalenalbaran > 0 and idpedido = " + str(p["idpedido"]))
    rows = cx["cur"].fetchall()
    numL = 1
    if len(rows) <= 0:
        return False

    sufijo = "01"
    if p["numenvio"] is not None:
        p["numenvio"] += 1
        if len(str(p["numenvio"])) == 1:
            sufijo = "0" + str(p["numenvio"])
        else:
            sufijo = str(p["numenvio"])

    rub110 = ET.SubElement(int15, "rub110")
    ET.SubElement(rub110, "activity_code").text = "GNS"
    ET.SubElement(rub110, "physical_depot_code").text = "GNS"
    ET.SubElement(rub110, "originator_code").text = "EL_GANSO"
    ET.SubElement(rub110, "receipt_reference").text = "P" + p["codigo"] + sufijo
    ET.SubElement(rub110, "receipt_type").text = "010"
    ET.SubElement(rub110, "receipt_reason_code").text = "PRO"
    ET.SubElement(rub110, "work_mode_code").text = "REC"
    ET.SubElement(rub110, "original_code").text = p["codproveedor"]

    ET.SubElement(rub110, "carrier_arrival_date_century").text = str(p["fechaentrada"])[0:2]
    ET.SubElement(rub110, "carrier_arrival_date_year").text = str(p["fechaentrada"])[2:4]
    ET.SubElement(rub110, "carrier_arrival_date_month").text = str(p["fechaentrada"])[5:7]
    ET.SubElement(rub110, "carrier_arrival_date_day").text = str(p["fechaentrada"])[8:10]
    ET.SubElement(rub110, "carrier_arrival_time").text = "0"

    rub119 = ET.SubElement(rub110, "rub119")
    ET.SubElement(rub119, "activity_code").text = "GNS"
    ET.SubElement(rub119, "physical_depot_code").text = "GNS"
    ET.SubElement(rub119, "originator_code").text = "EL_GANSO"
    ET.SubElement(rub119, "receipt_reference").text = "P" + p["codigo"] + sufijo
    ET.SubElement(rub119, "comment_line_no").text = "001"
    ET.SubElement(rub119, "comment_group").text = "OWN"

    if p["nombrealmacen"]:
        ET.SubElement(rub119, "comment").text = p["nombrealmacen"][0:70]
    else:
        ET.SubElement(rub119, "comment").text = ""

    for l in rows:
        rub120 = ET.SubElement(rub110, "rub120")
        ET.SubElement(rub120, "activity_code").text = "GNS"
        ET.SubElement(rub120, "physical_depot_code").text = "GNS"
        ET.SubElement(rub120, "originator_code").text = "EL_GANSO"
        ET.SubElement(rub120, "receipt_reference").text = "P" + p["codigo"] + sufijo
        ET.SubElement(rub120, "receipt_reference_line_no").text = str(numL)
        ET.SubElement(rub120, "item_code").text = str(l["barcode"])[0:16]
        ET.SubElement(rub120, "item_lv_code").text = "11"
        ET.SubElement(rub120, "level_1_quantity").text = str(int(l["cantidad"]))
        ET.SubElement(rub120, "owner_code").text = p["codalmacen"]
        numL += 1

    return True
