#! /usr/bin/python
from generaXmlProveedores import *

generaXmlProveedores()