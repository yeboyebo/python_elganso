import xml.etree.cElementTree as ET
from xml.etree.ElementTree import tostring
from util import *


def generaXmlViajesCli():
    xmlstring = ""
    res = {}
    res[0] = False
    res[1] = ""

    cx = creaConexion()

    try:
        prepOrd = ET.Element("preparation_orders")
        int16 = ET.SubElement(prepOrd, "int16")

        cx["cur"].execute("SELECT v.idviajemultitrans as idviaje, a.codalmacenidl as codalmacen, t.codtienda as codtienda, c.nombre as nombrecliente, v.fecha as fecha, c.codcliente as codcliente, d.direccion as direccion, d.codpostal as codpostal, d.poblacion as ciudad, d.provincia as provincia, pa.codiso3 as codpais, ag.nombre as agenciatransidl, ag.descripcion as commentidl FROM tpv_viajesmultitransstock v LEFT JOIN tpv_multitransstock m ON v.codmultitransstock = m.codmultitransstock left outer JOIN almacenesidl a on v.codalmaorigen = a.codalmacen inner join almacenes d on v.codalmadestino = d.codalmacen left outer join tpv_tiendas t on d.codtienda = t.codtienda inner join clientes c on c.codcliente = t.codcliente left outer join paises pa on d.codpais = pa.codpais inner join agenciastrans_idl ag on c.codagenciaidl = ag.codagenciaidl WHERE v.codalmaorigen in ('IALS','IMEX','IAND','IAPE','ICHI','IMAY','AIDL') and (m.estado = 'Aceptado' or m.estado is null) and v.fecha >= '2018-07-18' and azkarok = false and v.idviajemultitrans in (select idviajemultitrans from tpv_lineasmultitransstock where idviajemultitrans = v.idviajemultitrans) AND v.estado = 'PTE ENVIO' order by v.idviajemultitrans LIMIT 1")
        # and ag.codagenciaidl = 'DACHSER_02'selec

        rows = cx["cur"].fetchall()
        idViaje = False
        if len(rows) > 0:
            for p in rows:
                idViaje = p["idviaje"]
                if not creaXmlEnvioViajeCli(p, int16, cx):
                    print("No hay viajes con lineas que enviar")
                    return False

            tree = ET.ElementTree(prepOrd)
            tree.write("./preparaciones/xmlViajesCli_" + idViaje + ".xml")

            xmlstring = tostring(prepOrd, 'utf-8', method="xml").decode("ISO8859-15")
            # datosCX = dameDatosConexion("WSIDL_ENVPREP_TEST", cx)
            datosCX = dameDatosConexion("WSIDL_ENVPREP", cx)
            header = datosCX["header"]
            url = datosCX["url"]
            result = post_request(url, header, xmlstring)
            # result = "<recepOrders_response><int15><rub110><activity_code>GNS</activity_code><physical_depot_code>GNS</physical_depot_code><status>OK</status><error_descriptions><error_description></error_description></error_descriptions></rub110></int15></recepOrders_response>"
            print(result)

            status = False
            if not result:
                res[0] = False
                res[1] = result
                print(result)
                print("Error enviando pedido")
                return False
            else:
                res[0] = True
                res[1] = result

                root = ET.fromstring(result)
                child = root.find('int16/rub110')
                if child:
                    status = child.find("status").text

                tree = ET.ElementTree(root)
                tree.write("./preparaciones/resViajesCli" + idViaje + ".xml")

                idlog = registraLog("ENV_SOLENVIOSV", xmlstring, res, cx)
                if status:
                    if status == "OK":
                        cx["cur"].execute("UPDATE tpv_viajesmultitransstock SET azkarok = true where idviajemultitrans = '" + str(idViaje) + "'")
                        cx["conn"].commit()
                #    else:
                #        error = child.find("error_descriptions/error_description").text
                #        print(error)
                #        cx["cur"].execute("UPDATE pedidoscli SET fichero = 'ERROR: " + str(idlog) + "' where idpedido = " + str(idPedido))
        else:
            print("No hay viajes que enviar")
            return True

    except Exception as e:
        res[0] = False
        res[1] = e
        print(e)
        return False

    cierraConexion(cx)
    generaXmlViajesCli()
    return True


def creaXmlEnvioViajeCli(p, int16, cx):
    cx["cur"].execute("SELECT barcode, cantpteenvio as cantidad, idlinea, descripcion, numlinea FROM tpv_lineasmultitransstock WHERE cantidad > 0 and idviajemultitrans = '" + str(p["idviaje"] + "'"))
    rows = cx["cur"].fetchall()
    if len(rows) <= 0:
        return False

    sufijo = "01"

    codcliente = str(p["codcliente"])
    codtienda = str(p["codtienda"])
    if(codtienda):
        codcliente = codtienda + "_" + codcliente

    codcliente = codcliente[0:13]

    rub110 = ET.SubElement(int16, "rub110")
    ET.SubElement(rub110, "activity_code").text = "GNS"
    ET.SubElement(rub110, "physical_depot_code").text = "GNS"
    ET.SubElement(rub110, "originator_code").text = "EL_GANSO"
    ET.SubElement(rub110, "originator_reference").text = "V" + p["idviaje"] + sufijo
    ET.SubElement(rub110, "preparation_type_code").text = "010"
    ET.SubElement(rub110, "end_consignee_code").text = codcliente
    ET.SubElement(rub110, "planned_final_delivery_date_century").text = str(p["fecha"])[0:2]
    ET.SubElement(rub110, "planned_final_delivery_date_year").text = str(p["fecha"])[2:4]
    ET.SubElement(rub110, "planned_final_delivery_date_month").text = str(p["fecha"])[5:7]
    ET.SubElement(rub110, "planned_final_delivery_date_day").text = str(p["fecha"])[8:10]

    rub111 = ET.SubElement(rub110, "rub111")
    ET.SubElement(rub111, "activity_code").text = "GNS"
    ET.SubElement(rub111, "physical_depot_code").text = "GNS"
    ET.SubElement(rub111, "originator_code").text = "EL_GANSO"
    ET.SubElement(rub111, "originator_reference").text = "V" + p["idviaje"] + sufijo
    ET.SubElement(rub111, "preparation_order_reason_code").text = "B2C"
    ET.SubElement(rub111, "load_grouping").text = str(p["agenciatransidl"])

    rub11A = ET.SubElement(rub110, "rub11A")
    ET.SubElement(rub11A, "activity_code").text = "GNS"
    ET.SubElement(rub11A, "physical_depot_code").text = "GNS"
    ET.SubElement(rub11A, "originator_code").text = "EL_GANSO"
    ET.SubElement(rub11A, "originator_reference").text = "V" + p["idviaje"] + sufijo
    ET.SubElement(rub11A, "address_type_code").text = "010"

    ET.SubElement(rub11A, "name_or_company_name_in_address").text = quitaIntros(str(p["nombrecliente"]))[0:35]

    direccion = quitaIntros(str(p["direccion"]))
    ET.SubElement(rub11A, "street_and_number_and_or_po_box").text = direccion[0:35]
    if len(direccion) > 35:
        ET.SubElement(rub11A, "additional_addres_data_1").text = direccion[35:len(direccion)]

    ET.SubElement(rub11A, "additional_address_data_2").text = str(p["provincia"])[0:35]
    ET.SubElement(rub11A, "post_code_area_name").text = str(p["ciudad"])[0:35]
    ET.SubElement(rub11A, "postal_code").text = str(p["codpostal"])[0:9]
    ET.SubElement(rub11A, "iso_country_code").text = str(p["codpais"])[0:3]

    rub119 = ET.SubElement(rub110, "rub119")
    ET.SubElement(rub119, "activity_code").text = "GNS"
    ET.SubElement(rub119, "physical_depot_code").text = "GNS"
    ET.SubElement(rub119, "originator_code").text = "EL_GANSO"
    ET.SubElement(rub119, "originator_reference").text = "V" + p["idviaje"] + sufijo
    ET.SubElement(rub119, "comment_line_no").text = "1"
    ET.SubElement(rub119, "comment_group").text = "TRA"
    ET.SubElement(rub119, "comment").text = str(p["commentidl"])

    for l in rows:
        rub120 = ET.SubElement(rub110, "rub120")
        ET.SubElement(rub120, "activity_code").text = "GNS"
        ET.SubElement(rub120, "physical_depot_code").text = "GNS"
        ET.SubElement(rub120, "originator_code").text = "EL_GANSO"
        ET.SubElement(rub120, "originator_reference").text = "V" + p["idviaje"] + sufijo
        ET.SubElement(rub120, "originator_reference_line_no").text = str(int(l["numlinea"]))
        ET.SubElement(rub120, "item_code").text = str(l["barcode"])[0:16]
        ET.SubElement(rub120, "item_lv_code").text = "11"
        ET.SubElement(rub120, "level_1_quantity_to_prepare").text = str(int(l["cantidad"]))
        ET.SubElement(rub120, "owner_code_to_prepare").text = str(p["codalmacen"])[0:3]
        ET.SubElement(rub120, "grade_code_to_prepare").text = "STD"

    return True
